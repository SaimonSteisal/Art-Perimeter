const AdminApp = (() => {
  const tokenKey = 'art-perimeter-admin-token';
  const editableFields = [
    { key: 'site_title', label: 'Заголовок сайта' },
    { key: 'company_name', label: 'Название компании' },
    { key: 'phone_main', label: 'Основной телефон' },
    { key: 'phone_secondary', label: 'Дополнительный телефон' },
    { key: 'email', label: 'Email' },
    { key: 'address', label: 'Адрес' },
    { key: 'hours', label: 'Часы работы' },
    { key: 'hero_title', label: 'Hero заголовок' },
    { key: 'hero_subtitle', label: 'Hero подпись' },
    { key: 'hero_description', label: 'Hero описание', type: 'textarea' },
    { key: 'hero_cta_text', label: 'Текст CTA' },
    { key: 'hero_cta_link', label: 'Ссылка CTA' },
    { key: 'hero_bg', label: 'Фон Hero (URL)' },
    { key: 'services_title', label: 'Заголовок услуг' },
    { key: 'services_desc', label: 'Описание услуг', type: 'textarea' },
    { key: 'contacts_title', label: 'Заголовок контактов' },
    { key: 'contacts_desc', label: 'Описание контактов', type: 'textarea' },
    { key: 'footer_text', label: 'Текст футера' }
  ];

  let content = null;

  function getToken() {
    return localStorage.getItem(tokenKey);
  }

  function setToken(token) {
    localStorage.setItem(tokenKey, token);
  }

  function clearToken() {
    localStorage.removeItem(tokenKey);
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function showPanel() {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('admin-screen').classList.remove('hidden');
  }

  function showLogin() {
    document.getElementById('admin-screen').classList.add('hidden');
    document.getElementById('login-screen').classList.remove('hidden');
  }

  async function fetchContent() {
    const response = await fetch('/api/data');
    if (!response.ok) {
      throw new Error('Не удалось загрузить контент');
    }
    content = await response.json();
  }

  function renderForm() {
    const form = document.getElementById('content-form');
    form.innerHTML = editableFields
      .map((field) => {
        const value = content[field.key] ?? '';
        if (field.type === 'textarea') {
          return `
            <div class="admin-field">
              <label for="${field.key}">${field.label}</label>
              <textarea id="${field.key}" data-field="${field.key}">${escapeHtml(value)}</textarea>
            </div>
          `;
        }
        return `
          <div class="admin-field">
            <label for="${field.key}">${field.label}</label>
            <input class="calc-input" id="${field.key}" data-field="${field.key}" value="${escapeHtml(value)}" />
          </div>
        `;
      })
      .join('');
  }

  async function fetchLeads() {
    const response = await fetch(`/api/leads?token=${encodeURIComponent(getToken() || '')}`);
    const leadsList = document.getElementById('leads-list');

    if (!response.ok) {
      leadsList.innerHTML = '<p class="hint">Не удалось загрузить заявки.</p>';
      return;
    }

    const leads = await response.json();
    if (!leads.length) {
      leadsList.innerHTML = '<p class="admin-muted">Заявок пока нет.</p>';
      return;
    }

    leadsList.innerHTML = leads
      .map(
        (lead) => `
          <article class="lead-card">
            <div class="lead-meta">${escapeHtml(lead.date || '')}</div>
            <strong>${escapeHtml(lead.name || 'Без имени')}</strong>
            <p>${escapeHtml(lead.phone || '')}</p>
            <p>${escapeHtml(lead.comment || '')}</p>
            ${lead.estimate ? `<p>Оценка: ${escapeHtml(lead.estimate)} ₽</p>` : ''}
            ${lead.fence ? `<p>Тип: ${escapeHtml(lead.fence)}</p>` : ''}
          </article>
        `
      )
      .join('');
  }

  async function hydrate() {
    await fetchContent();
    renderForm();
    await fetchLeads();
    showPanel();
  }

  async function login(password) {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || 'Ошибка авторизации');
    }

    setToken(data.token);
  }

  function collectForm() {
    const newContent = {};
    document.querySelectorAll('[data-field]').forEach((field) => {
      newContent[field.dataset.field] = field.value.trim();
    });
    return newContent;
  }

  async function save() {
    const status = document.getElementById('save-status');
    status.textContent = '';

    const response = await fetch('/api/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token: getToken(),
        newContent: collectForm()
      })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Не удалось сохранить');
    }

    status.style.color = '#9ad19d';
    status.textContent = 'Изменения сохранены.';
  }

  function bind() {
    document.getElementById('login-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const errorNode = document.getElementById('login-error');
      errorNode.textContent = '';

      try {
        await login(document.getElementById('password').value);
        await hydrate();
      } catch (error) {
        errorNode.textContent = error.message;
      }
    });

    document.getElementById('save-btn').addEventListener('click', async () => {
      try {
        await save();
      } catch (error) {
        const status = document.getElementById('save-status');
        status.style.color = '#ff7b7b';
        status.textContent = error.message;
      }
    });

    document.getElementById('refresh-leads-btn').addEventListener('click', () => {
      fetchLeads();
    });

    document.getElementById('logout-btn').addEventListener('click', () => {
      clearToken();
      showLogin();
    });
  }

  return {
    async init() {
      bind();
      if (getToken()) {
        try {
          await hydrate();
          return;
        } catch (error) {
          clearToken();
        }
      }
      showLogin();
    }
  };
})();

window.addEventListener('DOMContentLoaded', () => AdminApp.init());
