const App = (() => {
  const state = {
    content: null,
    calc: {
      fence: null,
      length: 30,
      extras: [],
      name: '',
      phone: '',
      comment: ''
    },
    step: 1
  };

  const sections = [
    { id: 'services', label: 'Услуги' },
    { id: 'calculator', label: 'Калькулятор' },
    { id: 'portfolio', label: 'Портфолио' },
    { id: 'contacts', label: 'Контакты' }
  ];

  function formatPrice(value) {
    return new Intl.NumberFormat('ru-RU').format(value) + ' ₽';
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function updateMeta(content) {
    document.title = content.site_title;
    const desc = document.querySelector('meta[name="description"]');
    if (desc) {
      desc.content = content.hero_description;
    }
    const stickyPhone = document.getElementById('sticky-phone');
    stickyPhone.href = `tel:${content.phone_main.replace(/\D/g, '')}`;
  }

  function renderHeader(content) {
    const navLinks = sections
      .map((item) => `<li><a href="#${item.id}">${item.label}</a></li>`)
      .join('');

    document.getElementById('header').innerHTML = `
      <div class="container header-inner">
        <a href="#" class="logo" aria-label="${escapeHtml(content.company_name)}">
          <span class="logo-icon">АП</span>
          <span>
            <span class="logo-name">${escapeHtml(content.company_name)}</span>
            <span class="logo-subtitle">${escapeHtml(content.hero_subtitle)}</span>
          </span>
        </a>
        <nav class="desktop-nav"><ul>${navLinks}</ul></nav>
        <div class="header-meta">
          <div class="header-contacts">
            <a class="header-phone" href="tel:${content.phone_main.replace(/\D/g, '')}">${escapeHtml(content.phone_main)}</a>
            <div class="header-sub">${escapeHtml(content.hours)}</div>
          </div>
          <button class="mobile-toggle" id="mobile-toggle" aria-label="Открыть меню">☰</button>
        </div>
      </div>
    `;

    document.getElementById('mobile-nav').innerHTML = sections
      .map((item) => `<a href="#${item.id}" data-menu-link>${item.label}</a>`)
      .join('');
  }

  function renderHero(content) {
    return `
      <section class="hero" style="background-image:url('${escapeHtml(content.hero_bg)}')">
        <div class="container hero-content">
          <p class="eyebrow">${escapeHtml(content.hero_subtitle)}</p>
          <h1>${escapeHtml(content.hero_title)}</h1>
          <p>${escapeHtml(content.hero_description)}</p>
          <div class="hero-actions">
            <a class="btn" href="${escapeHtml(content.hero_cta_link)}">${escapeHtml(content.hero_cta_text)}</a>
            <a class="btn btn-secondary" href="#contacts">Получить консультацию</a>
          </div>
          <div class="hero-stats">
            <div class="hero-stat"><strong>7+</strong><span>лет опыта в монтаже</span></div>
            <div class="hero-stat"><strong>2 года</strong><span>гарантия на работы</span></div>
            <div class="hero-stat"><strong>1-2 дня</strong><span>средний срок монтажа</span></div>
          </div>
        </div>
      </section>
    `;
  }

  function renderAdvantages(content) {
    return `
      <section class="features section">
        <div class="container">
          <div class="features-grid">
            ${content.advantages
              .map(
                (item) => `
                  <article class="feature-item">
                    <div class="feature-icon">${escapeHtml(item.icon)}</div>
                    <h3>${escapeHtml(item.title)}</h3>
                    <p>${escapeHtml(item.desc)}</p>
                  </article>
                `
              )
              .join('')}
          </div>
        </div>
      </section>
    `;
  }

  function renderCalculator(content) {
    return `
      <section id="calculator">
        <div class="container">
          <div class="section-title">
            <p class="eyebrow">Калькулятор</p>
            <h2>${escapeHtml(content.calc_title)}</h2>
            <p>${escapeHtml(content.calc_subtitle)}</p>
          </div>
          <div class="calc-wrapper">
            <div class="calc-progress"><div class="calc-progress-bar" id="calc-progress-bar"></div></div>

            <div class="calc-step active" data-step="1">
              <div class="step-title">1. Выберите тип ограждения</div>
              <div class="option-grid">
                ${content.calc_fences
                  .map(
                    (item) => `
                      <button class="option-card" type="button" data-fence="${escapeHtml(item.id)}">
                        <img src="${escapeHtml(item.img)}" alt="${escapeHtml(item.name)}" />
                        <span class="option-card-content">
                          <span class="option-card-title">${escapeHtml(item.name)}</span>
                          <span class="option-card-price">от ${formatPrice(item.price)} / м.п.</span>
                        </span>
                      </button>
                    `
                  )
                  .join('')}
              </div>
              <div class="hint" id="calc-hint-step-1"></div>
              <div class="calc-actions">
                <span></span>
                <button class="btn" type="button" id="next-step-1">Далее</button>
              </div>
            </div>

            <div class="calc-step" data-step="2">
              <div class="step-title">2. Укажите длину и дополнительные элементы</div>
              <div class="range-container">
                <div class="range-header">
                  <div>
                    <div class="range-label">Длина забора</div>
                    <div class="range-value" id="length-value">30 м</div>
                  </div>
                </div>
                <input id="length-range" class="range-slider" type="range" min="10" max="300" step="5" value="30" />
              </div>
              <div class="option-grid">
                ${content.calc_extras
                  .map(
                    (item) => `
                      <button class="option-card" type="button" data-extra="${escapeHtml(item.id)}">
                        <img src="${escapeHtml(item.img)}" alt="${escapeHtml(item.name)}" />
                        <span class="option-card-content">
                          <span class="option-card-title">${escapeHtml(item.name)}</span>
                          <span class="option-card-price">+ ${formatPrice(item.price)}</span>
                        </span>
                      </button>
                    `
                  )
                  .join('')}
              </div>
              <div class="live-total" id="live-total"></div>
              <div class="calc-actions">
                <button class="btn btn-secondary" type="button" id="prev-step-2">Назад</button>
                <button class="btn" type="button" id="next-step-2">Далее</button>
              </div>
            </div>

            <div class="calc-step" data-step="3">
              <div class="step-title">3. Оставьте контакты</div>
              <div class="result-box">
                <div>Ориентировочная стоимость</div>
                <div class="final-price" id="final-price"></div>
              </div>
              <div class="result-details" id="result-details"></div>
              <form id="lead-form">
                <input class="calc-input" type="text" id="lead-name" placeholder="Ваше имя" required />
                <input class="calc-input" type="tel" id="lead-phone" placeholder="Телефон" required />
                <textarea class="calc-input" id="lead-comment" placeholder="Комментарий"></textarea>
                <label class="checkbox">
                  <input type="checkbox" id="lead-consent" required />
                  <span>${escapeHtml(content.contacts_form_consent)}</span>
                </label>
                <div class="hint" id="calc-hint-step-3"></div>
                <div class="calc-actions">
                  <button class="btn btn-secondary" type="button" id="prev-step-3">Назад</button>
                  <button class="btn" type="submit">${escapeHtml(content.contacts_form_submit)}</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    `;
  }

  function renderServices(content) {
    return `
      <section class="section" id="services">
        <div class="container">
          <div class="section-title">
            <p class="eyebrow">Услуги</p>
            <h2>${escapeHtml(content.services_title)}</h2>
            <p>${escapeHtml(content.services_desc)}</p>
          </div>
          <div class="services-grid">
            ${content.services
              .map(
                (item) => `
                  <article class="service-card">
                    <img src="${escapeHtml(item.img)}" alt="${escapeHtml(item.title)}" />
                    <div class="service-card-content">
                      <h3>${escapeHtml(item.title)}</h3>
                      <p>${escapeHtml(item.desc)}</p>
                    </div>
                  </article>
                `
              )
              .join('')}
          </div>
        </div>
      </section>
    `;
  }

  function renderPortfolio(content) {
    return `
      <section class="section" id="portfolio">
        <div class="container">
          <div class="section-title">
            <p class="eyebrow">Портфолио</p>
            <h2>${escapeHtml(content.portfolio_title)}</h2>
            <p>${escapeHtml(content.portfolio_subtitle)}</p>
          </div>
          <div class="portfolio-grid">
            ${content.portfolio
              .map(
                (item) => `
                  <article class="portfolio-card">
                    <img src="${escapeHtml(item.img)}" alt="${escapeHtml(item.title)}" />
                    <div class="portfolio-card-content">
                      <h3>${escapeHtml(item.title)}</h3>
                      <p class="portfolio-tag">${escapeHtml(item.tag)}</p>
                    </div>
                  </article>
                `
              )
              .join('')}
          </div>
        </div>
      </section>
    `;
  }

  function renderContacts(content) {
    return `
      <section class="section" id="contacts">
        <div class="container">
          <div class="section-title">
            <p class="eyebrow">${escapeHtml(content.contacts_subtitle)}</p>
            <h2>${escapeHtml(content.contacts_title)}</h2>
            <p>${escapeHtml(content.contacts_desc)}</p>
          </div>
          <div class="contact-grid">
            <article class="contact-card">
              <h3>Контактная информация</h3>
              <div class="contact-list">
                <div class="contact-row">
                  <strong>Телефон</strong>
                  <a href="tel:${content.phone_main.replace(/\D/g, '')}">${escapeHtml(content.phone_main)}</a>
                </div>
                <div class="contact-row">
                  <strong>Доп. телефон</strong>
                  <a href="tel:${content.phone_secondary.replace(/\D/g, '')}">${escapeHtml(content.phone_secondary)}</a>
                </div>
                <div class="contact-row">
                  <strong>Email</strong>
                  <a href="mailto:${escapeHtml(content.email)}">${escapeHtml(content.email)}</a>
                </div>
                <div class="contact-row">
                  <strong>Адрес</strong>
                  <span>${escapeHtml(content.address)}</span>
                </div>
                <div class="contact-row">
                  <strong>Режим работы</strong>
                  <span>${escapeHtml(content.hours)}</span>
                </div>
              </div>
            </article>
            <article class="contact-card">
              <h3>${escapeHtml(content.contacts_form_title)}</h3>
              <form class="contact-form" id="quick-contact-form">
                <input class="calc-input" type="text" name="name" placeholder="Ваше имя" required />
                <input class="calc-input" type="tel" name="phone" placeholder="Телефон" required />
                <textarea class="calc-input" name="comment" placeholder="Что нужно сделать"></textarea>
                <label class="checkbox">
                  <input type="checkbox" required />
                  <span>${escapeHtml(content.contacts_form_consent)}</span>
                </label>
                <button class="btn" type="submit">${escapeHtml(content.contacts_form_submit)}</button>
              </form>
            </article>
          </div>
        </div>
      </section>
    `;
  }

  function renderFooter(content) {
    document.getElementById('footer').innerHTML = `
      <div class="container footer-inner">
        <span>${escapeHtml(content.footer_text)}</span>
        <a href="${escapeHtml(content.footer_privacy)}">Политика конфиденциальности</a>
      </div>
    `;
  }

  function getFence() {
    return state.content.calc_fences.find((item) => item.id === state.calc.fence);
  }

  function getSelectedExtras() {
    return state.content.calc_extras.filter((item) => state.calc.extras.includes(item.id));
  }

  function calculateEstimate() {
    const fence = getFence();
    const base = fence ? fence.price * Number(state.calc.length) : 0;
    const extras = getSelectedExtras().reduce((sum, item) => sum + item.price, 0);
    return {
      base,
      extras,
      total: base + extras
    };
  }

  function updateCalculationUI() {
    const estimate = calculateEstimate();
    const liveTotal = document.getElementById('live-total');
    const finalPrice = document.getElementById('final-price');
    const resultDetails = document.getElementById('result-details');

    if (liveTotal) {
      liveTotal.textContent = `Текущая оценка: ${formatPrice(estimate.total)}`;
    }

    if (finalPrice) {
      finalPrice.textContent = formatPrice(estimate.total);
    }

    if (resultDetails) {
      const fence = getFence();
      const extrasText = getSelectedExtras()
        .map((item) => item.name)
        .join(', ') || 'без доп. опций';
      resultDetails.innerHTML = `
        <p><strong>Тип:</strong> ${escapeHtml(fence ? fence.name : 'не выбран')}</p>
        <p><strong>Длина:</strong> ${escapeHtml(state.calc.length)} м</p>
        <p><strong>Дополнительно:</strong> ${escapeHtml(extrasText)}</p>
      `;
    }
  }

  function showStep(step) {
    state.step = step;
    document.querySelectorAll('.calc-step').forEach((node) => {
      node.classList.toggle('active', Number(node.dataset.step) === step);
    });
    const width = step === 1 ? '33.3%' : step === 2 ? '66.6%' : '100%';
    document.getElementById('calc-progress-bar').style.width = width;
    updateCalculationUI();
  }

  function showToast(message, isError = false) {
    const toast = document.getElementById('toast');
    const messageNode = document.getElementById('toast-message');
    messageNode.textContent = message;
    toast.classList.remove('hidden');
    toast.style.background = isError ? '#5d1f1f' : '#173d18';
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.add('hidden'), 2500);
  }

  async function sendLead(payload) {
    const response = await fetch('/api/leads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Ошибка отправки');
    }

    return data;
  }

  function bindCalculator() {
    document.querySelectorAll('[data-fence]').forEach((node) => {
      node.addEventListener('click', () => {
        state.calc.fence = node.dataset.fence;
        document.querySelectorAll('[data-fence]').forEach((btn) => btn.classList.remove('selected'));
        node.classList.add('selected');
        document.getElementById('calc-hint-step-1').textContent = '';
        updateCalculationUI();
      });
    });

    document.querySelectorAll('[data-extra]').forEach((node) => {
      node.addEventListener('click', () => {
        const extraId = node.dataset.extra;
        const exists = state.calc.extras.includes(extraId);
        state.calc.extras = exists
          ? state.calc.extras.filter((id) => id !== extraId)
          : [...state.calc.extras, extraId];
        node.classList.toggle('selected', !exists);
        updateCalculationUI();
      });
    });

    const lengthRange = document.getElementById('length-range');
    const lengthValue = document.getElementById('length-value');
    lengthRange.addEventListener('input', () => {
      state.calc.length = Number(lengthRange.value);
      lengthValue.textContent = `${state.calc.length} м`;
      updateCalculationUI();
    });

    document.getElementById('next-step-1').addEventListener('click', () => {
      if (!state.calc.fence) {
        document.getElementById('calc-hint-step-1').textContent = 'Выберите тип ограждения.';
        return;
      }
      showStep(2);
    });

    document.getElementById('prev-step-2').addEventListener('click', () => showStep(1));
    document.getElementById('next-step-2').addEventListener('click', () => showStep(3));
    document.getElementById('prev-step-3').addEventListener('click', () => showStep(2));

    document.getElementById('lead-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const hint = document.getElementById('calc-hint-step-3');
      hint.textContent = '';

      state.calc.name = document.getElementById('lead-name').value.trim();
      state.calc.phone = document.getElementById('lead-phone').value.trim();
      state.calc.comment = document.getElementById('lead-comment').value.trim();

      if (!state.calc.name || !state.calc.phone) {
        hint.textContent = 'Заполните имя и телефон.';
        return;
      }

      try {
        const estimate = calculateEstimate();
        await sendLead({
          name: state.calc.name,
          phone: state.calc.phone,
          comment: state.calc.comment,
          source: 'calculator',
          fence: getFence()?.name || '',
          length: state.calc.length,
          extras: getSelectedExtras().map((item) => item.name),
          estimate: estimate.total
        });
        event.target.reset();
        showToast('Заявка отправлена');
        showStep(1);
      } catch (error) {
        hint.textContent = error.message;
      }
    });

    updateCalculationUI();
  }

  function bindQuickForm() {
    const form = document.getElementById('quick-contact-form');
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const payload = Object.fromEntries(formData.entries());
      payload.source = 'contact-form';

      try {
        await sendLead(payload);
        form.reset();
        showToast('Сообщение отправлено');
      } catch (error) {
        showToast(error.message, true);
      }
    });
  }

  function bindMenu() {
    const menu = document.getElementById('mobile-menu');
    const openBtn = document.getElementById('mobile-toggle');
    const closeBtn = document.getElementById('mobile-menu-close');

    openBtn?.addEventListener('click', () => menu.classList.remove('hidden'));
    closeBtn?.addEventListener('click', () => menu.classList.add('hidden'));
    document.querySelectorAll('[data-menu-link]').forEach((link) => {
      link.addEventListener('click', () => menu.classList.add('hidden'));
    });
  }

  async function load() {
    const response = await fetch('/api/data');
    if (!response.ok) {
      throw new Error('Не удалось загрузить контент');
    }

    state.content = await response.json();
    updateMeta(state.content);
    renderHeader(state.content);

    document.getElementById('app-container').innerHTML = [
      renderHero(state.content),
      renderAdvantages(state.content),
      renderCalculator(state.content),
      renderServices(state.content),
      renderPortfolio(state.content),
      renderContacts(state.content)
    ].join('');

    renderFooter(state.content);
    bindCalculator();
    bindQuickForm();
    bindMenu();
  }

  return {
    closeMobileMenu() {
      document.getElementById('mobile-menu')?.classList.add('hidden');
    },
    async init() {
      try {
        await load();
      } catch (error) {
        document.getElementById('app-container').innerHTML = `
          <section class="section">
            <div class="container">
              <div class="admin-card">
                <h1>Ошибка загрузки</h1>
                <p>${escapeHtml(error.message)}</p>
              </div>
            </div>
          </section>
        `;
      }
    }
  };
})();

window.App = App;
window.addEventListener('DOMContentLoaded', () => App.init());
